#!/bin/bash
pdflatex thesis-pirker.tex
bibtex thesis-pirker.aux
pdflatex thesis-pirker.tex
pdflatex thesis-pirker.tex
