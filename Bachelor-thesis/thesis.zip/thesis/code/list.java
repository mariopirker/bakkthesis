class List{
    List next;
    int val;

    void append(List ys){
        List cur = this;
        while (cur.next != null){
            cur = cur.next;
        };
        cur.next = ys;
    }
}

