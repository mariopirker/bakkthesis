public class Flatten {
public static IntList flatten(TreeList list){
  TreeList cur = list;
  IntList result = null;
  while (cur != null) {
    Tree tree = cur.value;
    if(tree != null) {
      IntList oldIntList = result;
      result = new IntList();
      result.value = tree.value;
      result.next = oldIntList;
      TreeList oldCur = cur;
      cur = new TreeList();
      cur.value = tree.left;
      cur.next = oldCur;
      oldCur.value = tree.right;
    } else {
       cur = cur.next;
    }
  }
  return result;
}
